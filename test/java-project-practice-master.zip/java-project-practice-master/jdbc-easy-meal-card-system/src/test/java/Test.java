/**
 * @Description:
 * @author: Gao Hang Hang
 * @date 2019/01/22 22:01
 */
public class Test {
    public static void main(String[] args) {
        System.out.println("ddd\n");
    }
}
