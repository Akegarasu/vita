# JDBC简单练习项目，简易饭卡系统

> 项目参考链接 [JAVA的JDBC的简单练习项目，一个简单的饭卡系统](https://blog.csdn.net/m0_37961948/article/details/71139397)

## 效果图

![](https://ws3.sinaimg.cn/large/006tNc79ly1fzfqn2neo2j30hl0fydhq.jpg)