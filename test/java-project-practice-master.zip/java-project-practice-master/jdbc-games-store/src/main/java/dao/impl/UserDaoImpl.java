package dao.impl;

import dao.UserDao;

/**
 * @Description:
 * @author: Gao Hang Hang
 * @date 2019/01/23 10:09
 */
public class UserDaoImpl implements UserDao {
    public int UserRes(String id, String password) {
        return 0;
    }
}
