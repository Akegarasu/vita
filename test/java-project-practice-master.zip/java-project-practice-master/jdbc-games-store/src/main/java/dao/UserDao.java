package dao;

/**
 * @Description:
 * @author: Gao Hang Hang
 * @date 2019/01/23 10:08
 */
public interface UserDao {
    public abstract int UserRes(String id, String password);
}
