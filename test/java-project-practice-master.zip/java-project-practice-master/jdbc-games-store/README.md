# 基于JDBC的游戏商店项目(Java控制台版)

涵盖MySQL、JDBC、Java SE、接口编程等Java核心技术。 

![](https://ws3.sinaimg.cn/large/006tNc79ly1fzg9yj27f8j30bg0arjsp.jpg)

