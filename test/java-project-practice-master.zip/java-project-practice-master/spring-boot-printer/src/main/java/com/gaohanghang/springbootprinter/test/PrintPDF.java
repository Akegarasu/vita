package com.gaohanghang.springbootprinter.test;

import java.io.File;

/**
 * @Description: 这段代码提供了核心的打印工作
 * @author: Gao Hang Hang
 * @date 2019/03/07 18:16
 */
public class PrintPDF {
    public static void  printPDF() {
        String filePath = "";
        File file = new File(filePath);


    }
}
