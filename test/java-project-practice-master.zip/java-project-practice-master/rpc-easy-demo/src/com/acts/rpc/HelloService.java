package com.acts.rpc;

/**
 * @Description: 接口
 * @author: Gao Hang Hang
 * @date 2019/01/27 12:44
 */
public interface HelloService {
    String hello(String name);
}
