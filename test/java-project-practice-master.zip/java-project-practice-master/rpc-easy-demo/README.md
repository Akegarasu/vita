# JAVA实现一个简单的RPC+项目源码

> 原文来自 [JAVA实现一个简单的RPC+项目源码](https://blog.52itstyle.com/archives/84/)

## 效果

### 启动服务

![](https://ws2.sinaimg.cn/large/006tNc79ly1fzm7but9rpj30l10f6dh4.jpg)

### 调用服务

![](https://ws3.sinaimg.cn/large/006tNc79ly1fzm7cvfiecj30kq0iwwgi.jpg)


