java生成二维码

> 效果

![](https://ws3.sinaimg.cn/large/006tNc79ly1g2o2ba2e9ij305k05k07p.jpg)

![](https://ws2.sinaimg.cn/large/006tNc79ly1g2o2c408hgj305k05k0nd.jpg)

