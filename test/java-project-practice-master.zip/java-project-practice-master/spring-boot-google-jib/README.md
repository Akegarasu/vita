# Jib构建你的第一个java镜像

> 原文链接 https://juejin.im/post/5b4e9c316fb9a04fa01d39d6





