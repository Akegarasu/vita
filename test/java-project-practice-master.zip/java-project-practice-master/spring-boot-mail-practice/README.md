# 使用Spring Boot发送邮件

> 来自慕课网 [Spring Boot 发送邮件](https://www.imooc.com/video/17765)


![](https://ws2.sinaimg.cn/large/006tNc79ly1g053df7kzuj30jl0b7mxv.jpg)

![](https://ws3.sinaimg.cn/large/006tNc79ly1g053g4uy6ej30k90b93yo.jpg)

![](https://ws2.sinaimg.cn/large/006tNc79ly1g053hvke6kj30kk0b73ys.jpg)
