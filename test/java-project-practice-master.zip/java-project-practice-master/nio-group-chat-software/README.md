
Java-NIO实现项目演练，一小时带你们做一个群聊软件 clip
https://www.youtube.com/watch?v=Y_nDeRIahvE

> 运行效果


![](https://ws1.sinaimg.cn/large/006tNc79ly1g2jv8tj0t8j30jx07g3z0.jpg)

![](https://ws3.sinaimg.cn/large/006tNc79ly1g2jv8gwvqij30hf073t9s.jpg)

