# JDBC练习项目 "对面的女孩看过来"

> 项目来自[JDBC之"对岸的女孩看过来"](https://www.imooc.com/video/5433)


## 运行效果

![](https://ws1.sinaimg.cn/large/006tNc79ly1fzhyeznzhqj30bw0aswfi.jpg)