# SpringBoot操作MongoDB数据库，实现基本的增删改查

> 项目来自 https://github.com/souyunku/SpringBootExamples

