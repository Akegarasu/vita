package com.gaohanghang.mail.common.task;

import org.springframework.stereotype.Component;

/**
 * @Description: 统计失败邮件定时重新发送
 * @author: Gao Hang Hang
 * @date 2019/01/29 12:10
 */
@Component("sendMail")
public class SendMail {
    public void sendMail() {

    }
}
