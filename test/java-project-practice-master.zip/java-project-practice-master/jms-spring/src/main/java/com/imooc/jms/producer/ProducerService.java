package com.imooc.jms.producer;

/**
 * @Description:
 * @author: Gao Hang Hang
 * @date 2019/02/10 10:58
 */
public interface ProducerService {
    void sendMessage(String message);
}
