package com.gaohanghang.springbootmanagebooks.exception;

/**
 * @Description:
 * @author: Gao Hang Hang
 * @date 2019/02/28 12:42
 */
public class AddBooklistException extends RuntimeException {
    public AddBooklistException(String message) {
        super(message);
    }
}
