#!/usr/bin/env python
# -*-coding:utf-8-*-
# @Time : 2017/11/1 ~ 2019/9/1
# @Author : Allen Woo

plugins_routing_moudel = [{"from": "apps.plugins.warehouse_plugin.apis", "import": [
    "goods", "goods_type", "goods_category", "business"]}, ]
