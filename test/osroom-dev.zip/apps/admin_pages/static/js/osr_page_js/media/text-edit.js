    var media_type = "text";

