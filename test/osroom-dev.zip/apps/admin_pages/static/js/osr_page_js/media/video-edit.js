    var media_type = "video";
