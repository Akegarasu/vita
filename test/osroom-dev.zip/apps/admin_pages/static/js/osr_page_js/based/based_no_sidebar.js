    $("#sidebar-left").addClass("visible-xs")
